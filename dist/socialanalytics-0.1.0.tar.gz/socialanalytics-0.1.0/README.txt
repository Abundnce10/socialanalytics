===============
socialanalytics
===============

socialanalytics provides insight into how a specific URL performs on a variety of social networks.

Pinterest
======

Grabs the number of Pins for a URL.

    #!/usr/bin/env python
    from socialanalytics import pinterest

    pins_count = pinterest.getPins(target_url)



